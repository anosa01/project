import 'bootstrap/dist/js/bootstrap.min.js';
import 'bootstrap/dist/css/bootstrap.min.css';
import './css/style.css'

console.log("أهلا بك في متجر أنوسة للأنوثة")